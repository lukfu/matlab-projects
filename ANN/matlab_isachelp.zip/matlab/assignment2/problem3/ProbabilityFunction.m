
function val = ProbabilityFunction(b)
    val = 1./(1+exp(-2*b));
end