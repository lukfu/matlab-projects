

function neuronValue = GetNeuronValue(weights,input,theta)
    neuronValue = tanh( weights*input - theta);
end




















