

hold on
%0/1
dist=2;
values=[0,0,0,0   0,0,0,0];
DrawSpheres(values)
DrawCube(dist)
view(15,20)

%% 1/1
values=[0,0,0,1   0,0,0,0];
DrawSpheres(values)
DrawCube(dist)
view(15,20)
%possibilities 
%% 2
values=[0,0,1,1,   0,0,0,0];
DrawSpheres(values)
DrawCube(dist)
view(15,20)
%% 
values=[1,0,0,1,   0,0,0,0];
DrawSpheres(values)
DrawCube(dist)
view(15,20)
%% 
values=[0,0,0,1,   1,0,0,0];
DrawSpheres(values)
DrawCube(dist)
view(15,20)
%% 3
values=[1,1,1,0,   0,0,0,0];
DrawSpheres(values)
DrawCube(dist)
view(15,20)
%%
values=[1,0,1,0,   0,1,0,0];
DrawSpheres(values)
DrawCube(dist)
view(15,20)
%%
values=[1,0,0,1,   0,1,0,0];
DrawSpheres(values)
DrawCube(dist)
view(15,20)
%% 4/1
values=[1,1,1,1,   0,0,0,0];
DrawSpheres(values)
DrawCube(dist)
view(15,20)
%%
values=[1,1,1,0,   1,0,0,0];
DrawSpheres(values)
DrawCube(dist)
view(15,20)
%%
values=[1,1,1,0,   0,1,0,0];
DrawSpheres(values)
DrawCube(dist)
view(15,20)
%%
values=[1,0,0,1,   1,0,0,1];
DrawSpheres(values)
DrawCube(dist)
view(15,20)
%values=[0,0,1,1,   1,1,0,0];
%DrawSpheres(values)
%DrawCube(dist)
%view(15,20)

%%
values=[1,0,0,1,   0,1,1,0];
DrawSpheres(values)
DrawCube(dist)
view(15,20)


































