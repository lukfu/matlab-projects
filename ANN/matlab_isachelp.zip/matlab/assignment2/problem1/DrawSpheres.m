

function DrawSpheres(values)
    for i=1:length(values)
       DrawSphere(i,values(i)) 
    end
end
