T=1E4;
r=linspace(0,1E2,T);
theta=linspace(0,2*pi,T);
b=10;
k=4*theta+r.^2;
ival = abs(k-b)<2222;
clf
polarplot(theta(ival),r(ival),'r.')






