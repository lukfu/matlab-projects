function folder_path
    %paths might need to be changed after Course is over
    folder1 = 'C:\Users\46723\Desktop\LP4\spatial statistics and image analysis\TMS016_Matlab\TMS016_Matlab';
    addpath(folder1)
    folder2 = 'C:\Users\46723\Desktop\LP4\spatial statistics and image analysis\data_AND_images';
    addpath(folder2)
    tms016path
end