function population = InitializePopulation(populationSize,numberOfGenes)
    population = rand(populationSize, numberOfGenes);
end