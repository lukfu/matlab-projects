function func = FunctionPSO(x,y)
    func = (x.^2 + y - 11).^2 + (x + y.^2 - 7).^2;
end